YesdreamDuel={--决斗
        mode_message={
            message="模式切换成功。\n当前模式:";
            difficult={{"根本不可能输掉嘛"};
            {"什么嘛超弱的"};
            {"公平交手"};
            {"幸运女神也救不了你"};
            {"我们在期待一个勇者"};}
            };
        duel_false={"一天只能决斗一次哦，不过嘛你要是不服气的话--也还是只能决斗一次"};
        message="{before}\n-----\n{dicename}\nsum:{dicesum}\n{dicenum}\n{player}\nsum:{playersum}\n{playernum}\n-----\n记：{result1}/10={result}分\n{after}";
        before={"看来{player}想向我发起决斗，呼呼，那我就接下了"};
        after={
            {"完胜，这是彻彻底底的完胜啊哈哈哈"};
            {"啧，就差一点就完胜了（懊恼）"};
            {"看看！看看！这就是自不量力来挑战我的下场"};
            {"哼哼，看这天堑般的差距！"};
            {"认输了没有，嘿嘿，见识到实力的差距了吧"};
            {"木大木大，至少再回去修炼个几百年爆裂魔法再来挑战我"};
            {"(得意洋洋的目光)"};
            {"你要是现在向我求饶我也不是不能原谅你哦.嗯？还敢不敢挑战我了？（笑）"};
            {"明天再来也是一样的下场嘿嘿（叉腰）"};
            {"木大木大木大，全部木大"};
            {"这么悬殊的比分可是少见的哦？"};
            {"我觉得你可以跟悠悠学学"};
            {"还要来吗？再来也是一样的啦"};
            {"要不要我下次放你一马？"};
            {"嘿嘿嘿，我可绝对没作弊"};
            {"嘛，既然输了就付出代价吧，（拽住）来来，我看那边那家店的汉堡肉不错"};
            {"嘛，既然输了就付出代价吧，看见那边正在嚼嚼嚼的miku了没，把她手里的大葱抢来给我"};
            {"看起来你很不服嘛,但是不服也没用，我赢了就是我赢了"};
            {"嘛既然。。。既然输了就要付出代价，那个（扭捏），嗯，给我一个公主抱试试看"};
            {"呼呼，是我的完胜呢，认输了没有？"};
            {"你觉得靠次数就能赢我那你就错了嘿嘿"};
            {"嘛，又输了，也很正常嘛，毕竟！对手是我"};
            {"嘛，你又输了（揉揉脑袋）"};
            {"嘛，我赢了，我要吃薯片（趴在沙发上）"};
            {"表面上这是一个概率问题，实际上，就是我很强啦"};
            {"啧 啧 啧，太弱了，换个人来吧"};
            {"你！输！了！不服？可以啊，明天再来，我再赢你一次（笑）"};
            {"再试也没用啦，会输一次就会输一百次哦"};
            {"嗯哼~是我的大胜利"};
            {"不服？不服你就正面赢我啊"};
            {"喂。。。你盯着我干什么。。没有！我说没有灌铅就没有灌铅，这是公平的决斗。。。嗯。。公平的"};
            {"你觉得能赢我，嘿嘿，那是个幻觉，美丽的幻觉。"};
            {"之前也有个调查员像你那么自信，后来他被撕成了两半"};
            {"哦吼？我觉得我甚至可以让你一个骰子"};
            {"（拍肩）不要那么沮丧嘛，人生不就是大起大落落落落落落落落"};
            {"你请我吃顿饭这次就算你赢，怎么样？"};
            {"我觉得吧，你再来一百次，也是这个结果（笑）"};
            {"安啦，是我太厉害不是你太菜"};
            {"嗯哼？比分居然比我预料的还要高一点，算你有两下子"};
            {"(哼起了歌)"};
            {"来来来既然输了就不要不服，过来让我揍一拳"};
            {"哦吼，来来来就像说好的那样，输的人去给682换洗澡水"};
            {"（面露笑意地看着你）"};
            {"你输了~你输了~你输了！重要的事说三遍"};
            {"我可是骰娘哦？你怎么可能赢嘛"};
            {"赢是不可能让你赢的哦"};
            {"啊，居然被你拉到了这个分数，那就夸你一下好了"};
            {"看似你只差一分就赢了，实则这一分是天差地别"};
            {"这不是平局！我赢了！我说我赢了就是我赢了！"};
            {"库唔，不可能。。居然。这是我算错了，肯定是我算错了。"};
            {"居然。。。不对。。我赢了。。一定是我赢了（念叨）"};
            {"你觉得是你赢了就错了！这是Error，肯定是哪里出错了！"};
            {"？！居然趁我一时大意。。。"};
            {"这不对。。哪里不对！我不相信！"};
            {"你你你。。。我警告你，不要得意，我我明天就找回场子"};
            {"玛丽安姐！！！！！有人欺负我！打他！"};
            {"假。。。假的吧（跌倒）虽然只有几分但是居然。。让你赢了"};
            {"木大木大，都说了我让你一只手也。。。嗯？嗯？！（长久的沉默）"};
            {"这是幻觉。。。这一定是幻觉。。"};
            {"呜呜呜。你欺负我，我才没有哭！你给我记着！（跑开）"};
            {"（盯————）我记住你了"};
            {"（捂住头）什么嘛！明明灌了铅为什么还是输了"};
            {"我要求重来！重来！这个不算数！"};
            {"在我心里我赢了！分数不重要！嗯，实际分数没有任何意义！"};
            {"（小声）你等着，我一定是要用大失败找回场子"};
            {"这是什么情况，你是不是作弊了（嚼嚼嚼）"};
            {"你肯定作弊了对不对？"};
            {"哼！这次就算你赢了吧，愿赌服输，你想要啥？"};
            {"那啥。。。咱们当做什么都没发生好不好（递水）"};
            {"......@惠惠.botoff"};
            {"（看起来灌的铅还不够。。）咳咳，什么都没有，这次就算你运气好这次就算你运气好，哼，我看上去像是那么死不认账的人吗？"};
            {"嗯，我赢了，你不要说话，对，我赢了，我赢了，我我我我说我赢了就是我赢了！！我才没有哭！"};
            {"只不过是你一时运气好了那么一点点罢了"};
            {"哼，不要得意，等明天。。。"};
            {"这什么啊！还是我终于开始出现幻觉了？！为什么看起来好像是你赢了"};
            {"唔，哼，虽然看起来是你赢了，但是但是但是（声音逐渐变小）"};
            {"呐，你赢了，呐呐，按传统，赢的人要请吃饭啊"};
            {"这。。。（陷入沉思）"};
            {"我。。我居然输了，你你你你你"};
            {"唉？？巴尼尔先生明明说我今天会赢的啊"};
            {"（掀桌）"};
            {"能。。再来一次吗，我我我，我让你见识一下我的爆裂魔法作为交换"};
            {"这...嗯，这也在计算之中，我早就算到了你的分数会高一点，所以其实还是我赢了"};
            {"呐，你赢了，哼哼，我可没有那么小家子气，我可是红魔族第一的天才啊"};
            {"（移开视线默默遮住骰子）你，，你什么都没看见，我什么都没有扔"};
            {"唔，大家，朋友一场，这个这个，就当做我赢了怎么样啊，我我我我请你吃小龙虾，我的小龙虾料理可是一流的啊"};
            {"唔，今天我看起来状态不大好呢，因为你看，这个数字，原本那里应该有个负号的吧，为什么我看不清？"};
            {"肯定是因为刚刚放完爆裂魔法状态不好，是的，是这样的"};
            {"....敢不敢再来一次啊kura"};
            {"(长久的沉默)"};
            {"你看。。看在我给你投了这么多次骰子的份上。。大家当做什么都没有发生如何"};
            {"我觉得我们肯定有什么误会在哒（搓手），不如大家交个朋友怎么样"};
            {"？！居然。。如此悬殊的比分。。不可能不可能，刚刚程序出bug了，不如我们再来一次（小声）"};
            {"(摇摇摇)这个骰子质量有问题，不如我们换一个再来一次？"};
            {"你你你你，你欺负我，我要告诉玛丽安姐，回头她会来收拾你的！你给我记住！记住！"};
            {"！！！！！！！（一脸不可置信地原地晕倒）"};
            {"?居然。。我居然会输到这种地步。。你你你，你欺负我，我要退群！退群！"};
            {"完败？！这不可能？不可能？！你你。。你对我的骰子干了什么，不可能不可能不可能不可能*N....（逐渐失去高光）"};
        };
        func={};
    };

i=sdk.randomInt(1,100)

function YesdreamDuel.func.cdivision(div,dediv)
    return (div-(div%dediv))/dediv
end

function YesdreamDuel.func.roll(mode)
    return sdk.randomInt(1,100-mode*10)+mode*10
end

function YesdreamDuel.func.num(num)
    local dice={}
    dice[6]=0
    for i=1,5 do
        dice[i]=YesdreamDuel.func.roll(num)
        dice[6]=dice[6]+dice[i]
    end
    return dice
end

local function date()
    local time=os.date("%m").."-"..os.date("%d")
    return time
end

function YesdreamDuel.func.roll_duel(msg)
    if dream.api.getUserConf("duel_模式","duel","duel")==nil then
        dream.api.setUserConf("duel_模式",3,"duel","duel")
    end
    if (dream.api.getUserConf("duel时间",msg.fromQQ,"duel") or 0)~=date() then
        dream.api.setUserConf("duel时间",date(),msg.fromQQ,"duel")
        local mode=(dream.api.getUserConf("duel_模式","duel","duel") or 3)
        local dice=YesdreamDuel.func.num(mode)
        local dice1=dice[1].."、"..dice[2].."、"..dice[3].."、"..dice[4].."、"..dice[5]
        local player=YesdreamDuel.func.num(6-mode)
        local player1=player[1].."、"..player[2].."、"..player[3].."、"..player[4].."、"..player[5]
        local result1=player[6]-dice[6]
        local result=YesdreamDuel.func.cdivision(result1,10)
        local before_message=YesdreamDuel.before[sdk.randomInt(1,#YesdreamDuel.before)] or "占位输出"
        local after_message=YesdreamDuel.after[result+49][sdk.randomInt(1,#YesdreamDuel.after[result+50])] or "占位输出"
        local message=YesdreamDuel.message:gsub("{before}",before_message):gsub("{after}",after_message):gsub("{dicename}",msg.fromDiceName):gsub("{player}",msg.fromNick):gsub("{dicesum}",dice[6]):gsub("{playersum}",player[6]):gsub("{dicenum}",dice1):gsub("{playernum}",player1):gsub("{result}",result):gsub("{result1}",result1)
        return message
    else
        return YesdreamDuel.duel_false[sdk.randomInt(1,#YesdreamDuel.duel_false)]
    end
end
dream.command.set("duel","duel",YesdreamDuel.func.roll_duel)

function YesdreamDuel.func.difficult_set(msg)
    if dream.deter.master(msg) then
        local mode=dream.tonumber(msg.fromMsg:match("%d"))
        if mode>=1 and mode<=5 then
            dream.api.setUserConf("duel_模式",mode,"duel","duel")
            local message=YesdreamDuel.mode_message.message..(YesdreamDuel.mode_message.difficult[mode][sdk.randomInt(1,#YesdreamDuel.mode_message.difficult[mode])] or "占位输出")
            return message
        else
            return "输入范围错误，范围应为1-5"
        end
    end
    return ""
end
dream.command.set("duel","changeduel",YesdreamDuel.func.difficult_set)

function YesdreamDuel.func.difficult_check(msg)
    local mode= dream.api.setUserConf("duel_模式",mode,"duel","duel") or 3
    local message=YesdreamDuel.mode_message.message..(YesdreamDuel.mode_message.difficult[mode][sdk.randomInt(1,#YesdreamDuel.mode_message.difficult[mode])] or "占位输出")
    return message
end
dream.command.set("duel","checkduel",YesdreamDuel.func.difficult_check)

return {
    id = "duel",
    version = "1.1.2",
    help = "--梦真duel--",
    author = "雨岚之忆",
    
    mode = true
  }
