---
description: Nullam urna elit, malesuada eget finibus ut, ac tortor.

hide:
  - navigation # Hide navigation
  - toc        # Hide table of contents
---


#
<span class="astral-dice">Astral Dice</span>

<span class="stable-dice">最稳定的骰娘</span>

[开始](1.md){: .md-button }
[问题反馈](https://astral.snoweven.com/t/feedback){: .md-button }

<!-- index.md 或特定页面的Markdown文件 -->
<body class="specific-page">

</body>
<footer class="my-footer">
    <!-- footer内容 -->
</footer>