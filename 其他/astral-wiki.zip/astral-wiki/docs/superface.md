|文本输入|超级表情mirai码|表情mirai码|cq码|
|:----:|:----:|:----:|:----:|
|/流泪|[mirai:superface:5,16,1,]|[mirai:face:5]|[CQ:face,id=5]/流泪|
|/打call|[mirai:superface:311,1,1,]|[mirai:face:311]|[CQ:face,id=311]/打call|
|/变形|[mirai:superface:312,2,1,]|[mirai:face:312]|[CQ:face,id=312]/变形|
|/仔细分析|[mirai:superface:314,4,1,]|[mirai:face:314]|[CQ:face,id=314]/仔细分析|
|/菜汪|[mirai:superface:317,7,1,]|[mirai:face:317]|[CQ:face,id=317]/菜汪|
|/崇拜|[mirai:superface:318,8,1,]|[mirai:face:318]|[CQ:face,id=318]/崇拜|
|/比心|[mirai:superface:319,9,1]|[mirai:face:319]|[CQ:face,id=319]/比心|
|/庆祝|[mirai:superface:320,10,1,]|[mirai:face:320]|[CQ:face,id=320]/庆祝|
|/吃糖|[mirai:superface:324,12,1,]|[mirai:face:324]|[CQ:face,id=324]/吃糖|
|/惊吓|[mirai:superface:325,14,1,]|[mirai:face:325]|[CQ:face,id=325]/惊吓|
|/花朵脸|[mirai:superface:337,22,1,]|[mirai:face:337]|[CQ:face,id=337]/花朵脸|
|/我想开了|[mirai:superface:338,20,1,]|[mirai:face:338]|[CQ:face,id=338]/我想开了|
|/舔屏|[mirai:superface:339,21,1]|[mirai:face:339]|[CQ:face,id=339]/舔屏|
|/打招呼|[mirai:superface:341,24,1,]|[mirai:face:341]|[CQ:face,id=341]/打招呼|
|/酸Q|[mirai:superface:342,26,1,]|[mirai:face:342]|[CQ:face,id=342]/酸Q|
|/我方了|[mirai:superface:343,27,1]|[mirai:face:343]|[CQ:face,id=343]/我方了|
|/大怨种|[mirai:superface:344,28,1]|[mirai:face:344]|[CQ:face,id=344]/大怨种|
|/红包多多|[mirai:superface:345,29,1,]|[mirai:face:345]|[CQ:face,id=345]/红包多多|
|/你真棒棒|[mirai:superface:346,25,1,]|[mirai:face:346]|[CQ:face,id=346]/你真棒棒|
|/戳一戳|[mirai:superface:181,37,1]|[mirai:face:181]|[CQ:face,id=181]/戳一戳|
|/太阳|[mirai:superface:74,35,1,]|[mirai:face:74]|[CQ:face,id=74]/太阳|
|/月亮|[mirai:superface:75,36,1]|[mirai:face:75]|[CQ:face,id=75]/月亮|
|/敲敲|[mirai:superface:351,30,1,]|[mirai:face:351]|[CQ:face,id=351]/敲敲|
|/坚强|[mirai:superface:349,32,1]|[mirai:face:349]|[CQ:face,id=349]/坚强|
|/贴贴|[mirai:superface:350,31,1,]|[mirai:face:350]|[CQ:face,id=350]/贴贴|
|/略略略|[mirai:superface:395,41,1,]|[mirai:face:395]|[CQ:face,id=395]/略略略|
|/篮球|[mirai:superface:114,13,2,1]|[mirai:face:114]|[CQ:face,id=114]/篮球|
|/生气|[mirai:superface:326,15,1,]|[mirai:face:326]|[CQ:face,id=326]/生气|
|/蛋糕|[mirai:superface:53,17,1,]|[mirai:face:]|[CQ:face,id=137]/蛋糕|
|/鞭炮|[mirai:superface:137,18,1,]|[mirai:face:137]|[CQ:face,id=137]/鞭炮|
|/烟花|[mirai:superface:333,19,1,]|[mirai:face:333]|[CQ:face,id=333]/烟花|
|【/接龙】|[mirai:superface:392,38,3,0]|[mirai:face:392]|[CQ:face,id=392]|


以上是一些超级表情与其对应的mirai，cq码。其实写到这里，我们可以得出这样一个结论:
>mirai 码和 cq 码表示常规表情时，二者几乎可以通用，而超级表情只有 mirai 可以识别，且第一位与常规表情相同


注意：`接龙`和`篮球`可能无法识别