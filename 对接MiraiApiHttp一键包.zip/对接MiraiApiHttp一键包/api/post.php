<?php
$headerArray =array("Content-type:application/json;charset='utf-8'","Accept:application/json");
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL,$_GET["url"]);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch,CURLOPT_POST,1);
curl_setopt($ch,CURLOPT_POSTFIELDS,$_GET["data"]);
curl_setopt($ch,CURLOPT_HTTPHEADER,$headerArray);
$data = curl_exec($ch);
curl_close($ch);
echo $data;