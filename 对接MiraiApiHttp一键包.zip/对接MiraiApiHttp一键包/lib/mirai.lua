-- 本库为Dream与mirai-api进行交互的lua扩展库
-- 作者：筑梦师V2.0&乐某人

if not dream.MiraiApiHttp then
  return nil
end

local verifyKey = dream.plugin.getConfig("MiraiApiHttp","verifyKey")
local port = dream.plugin.getConfig("MiraiApiHttp","http") -- MiraiApiHttp的端口
local mirai = {}
local http = {}
http.get = ZhaoDiceSDK.network.httpGet
http.url = "http://localhost:"..port
port = dream.plugin.getConfig("MiraiApiHttp","server") -- php web内置服务器的端口
http.post = "http://localhost:"..port.."/api/post.php?url="


-- 获取一个激活的sessionKey
function mirai.GetSessionKey(verifykey,qq)
  local qq = qq or dream.api.getDiceQQ()
  local verifyKey = verifykey or verifyKey
  local url = http.url.."/verify"
  local data = {}
  data["verifyKey"] = dream.tostring(verifyKey)
  data = json.encode(data)
  local post = http.post..url.."&data="..data
  local msg = http.get(post)
  msg = json.decode(msg)
  session = msg.session
  url = http.url.."/bind"
  data = {
    sessionKey = session,
    qq = qq
  }
  data = json.encode(data)
  post = http.post..url.."&data="..data
  msg = http.get(post)
  msg = json.decode(msg)
  if msg.code == 0 then
    return session
  else
    error("获取SessionKey失败！错误信息："..msg.msg)
  end
end

-- 释放一个sessionKey
function mirai.ReleaseSessionKey(session,qq)
  local qq = qq or dream.api.getDiceQQ()
  local url = http.url.."/release"
  local data = {
    sessionKey = session,
    qq = qq
  }
  data = json.encode(data)
  url = http.post..url.."&data="..data
  local msg = http.get(url)
  msg = json.decode(msg)
  if msg.code == 0 then
    return true
  else
    return false,msg.msg
  end
end

-- 获取好友列表
function mirai.friendList()
  local session = mirai.GetSessionKey()
  local url = http.url.."/friendList?sessionKey="..session
  local msg = http.get(url)
  msg = json.decode(msg).data
  mirai.ReleaseSessionKey(session)
  return msg
end

-- 获取群列表
function mirai.groupList()
  local session = mirai.GetSessionKey()
  local url = http.url.."/groupList?sessionKey="..session
  local msg = http.get(url)
  msg = json.decode(msg).data
  mirai.ReleaseSessionKey(session)
  return msg
end

-- 群成员列表
function mirai.memberList(target)
  local session = mirai.GetSessionKey()
  local url = http.url.."/memberList?sessionKey="..session.."&target="..target
  local msg = http.get(url)
  msg = json.decode(msg).data
  mirai.ReleaseSessionKey(session)
  return msg
end

-- 发送好友消息
function mirai.sendFriendMessage(messageChain,msg,quote)
  local quote = quote or "0"
  local url = http.url.."/sendFriendMessage"
  local session = mirai.GetSessionKey()
  local target = msg.fromQQ
  quote = dream.tostring(quote)
  local data
  if quote == "0" then
    data = {
      sessionKey = session,
      target = target,
      messageChain = messageChain
    }
  else
    data = {
      sessionKey = session,
      target = target,
      quote = quote,
      messageChain = messageChain
    }
  end
  data = json.encode(data)
  url = http.post..url.."&data="..data
  local msg = http.get(url)
  mirai.ReleaseSessionKey(session)
  msg = json.decode(msg)
  if msg.code == 0 then
    return true,msg -- 虽然成功，但提供一个消息id以供回复
  else
    return false,msg.msg
  end
end

-- 发送群消息
function mirai.sendGroupMessage(messageChain,msg,quote)
  local quote = quote or "0"
  local url = http.url.."/sendGroupMessage"
  local session = mirai.GetSessionKey()
  local target
  if msg.isGroup then
    target = msg.fromGroup
  else
    error("你未提供群号！")
  end
  quote = dream.tostring(quote)
  local data
  if quote == "0" then
    data = {
      sessionKey = session,
      target = target,
      messageChain = messageChain
    }
  else
    data = {
      sessionKey = session,
      target = target,
      quote = quote,
      messageChain = messageChain
    }
  end
  data = json.encode(data)
  url = http.post..url.."&data="..data
  local msg = http.get(url)
  mirai.ReleaseSessionKey(session)
  msg = json.decode(msg)
  if msg.code == 0 then
    return true,msg -- 虽然成功，但提供一个消息id以供回复
  else
    return false,msg
  end
end

function mirai.sendMessage(messageChain,msg,quote)
  if msg.isGroup then
    return mirai.sendGroupMessage(messageChain,msg,quote)
  else
    return mirai.sendFriendMessage(messageChain,msg,quote)
  end
end

-- 撤回消息
function mirai.recall(id,msg)
  local id = dream.tostring(id)
  local session = mirai.GetSessionKey()
  local url = http.url.."/recall"
  local target
  if msg.isGroup then
    target = msg.fromGroup
  else
    target = msg.fromQQ
  end
  local data = {
    sessionKey = session,
    target = target,
    messageId = id
  }
  data = json.encode(data)
  url = http.post..url.."&data="..data
  local msg = http.get(url)
  msg = json.decode(msg)
  mirai.ReleaseSessionKey(session)
  if msg.code == 0 then
    return true
  else
    return false,msg.msg
  end
end
  
-- 禁言接口
--target：群号，memberId：QQ，time：秒
function mirai.mute(target,memberId,time)
  local target = dream.tostring(target)
  local memberId = dream.tostring(memberId)
  local time = dream.tostring(time)
  local url = http.url.."/mute"
  local session = mirai.GetSessionKey()
  local data = {
    sessionKey = session,
    target = target,
    memberId = memberId,
    time = time
  }
  data = json.encode(data)
  url = http.post..url.."&data="..data
  local msg = http.get(url)
  mirai.ReleaseSessionKey(session)
  msg = json.decode(msg)
  if msg.code == 0 then
    return true
  else
    return false,msg.msg
  end
end

function mirai.unmute(target,memberId)
  local target = dream.tostring(target)
  local memberId = dream.tostring(memberId)
  local url = http.url.."/unmute"
  local session = mirai.GetSessionKey()
  local data = {
    sessionKey = session,
    target = target,
    memberId = memberId
  }
  data = json.encode(data)
  url = http.post..url.."&data="..data
  local msg = http.get(url)
  mirai.ReleaseSessionKey(session)
  msg = json.decode(msg)
  if msg.code == 0 then
    return true
  else
    return false,msg.msg
  end
end

-- 踢人，有了管理员，让我们把黑名单用户踢了吧～
function mirai.kick(target,qq)
  local target = dream.tostring(target)
  local qq = dream.tostring(qq)
  local session = mirai.GetSessionKey()
  local tab = {
    sessionKey = session,
    target = target,
    memberId = qq,
    msg = "您已经被"..dream.nick.."踢出群"
  }
  tab = json.encode(tab)
  local url = http.url.."/kick"
  url = http.post..url.."&data="..tab
  local msg = http.get(url)
  msg = json.decode(msg)
  mirai.ReleaseSessionKey(session)
  if msg.code == 0 then
    return true
  else
    return false,msg.msg
  end
end

-- 删除好友，可用于检索黑名单
function mirai.deleteFriend(qq)
  local qq = dream.tostring(qq)
  local session = mirai.GetSessionKey()
  if qq == nil then
    error("缺少参数：<QQ>")
  end
  local friends = dream.api.getFriendsList()
  local bool
  for i=1,#friends.list do
    if dream.tostring(friends.list[i].uin) == qq then
      bool = true
      break
    else
      bool = false
    end
  end
  if bool == false then
    return false
  else
    local url = http.url.."/deleteFriend"
    local tab = {
      sessionKey = session,
      target = qq
    }
    tab = json.encode(tab)
    url = http.post..url.."&data="..tab
    local msg = http.get(url)
    msg = json.decode(msg)
    mirai.ReleaseSessionKey(session)
    if msg.code ~= 0 then
      return false,msg.msg
    else
      return true
    end
  end
end

function mirai.SetTitle(target,memberId,title)
  local target = dream.tostring(target)
  local memberId = dream.tostring(memberId)
  local session = mirai.GetSessionKey()
  local url = http.url.."/memberInfo"
  local list = dream.api.getGroupsList(target)
  if list == nil then
    return false,"没有这个群"
  end
  local x
  for i=1,#list.list do
    if dream.tostring(list.list[i].uin) == memberId then
      x = i
      break
    end
  end
  local name
  if list.list[x].nameCard == "" then
    name = list.list[x].nick
  else
    name = list.list[x].nameCard
  end
  local tab = {
    sessionKey = session,
    target = target,
    memberId = memberId,
    info = {
      name = name,
      specialTitle = title
    }
  }
  tab = json.encode(tab)
  url = http.post..url.."&data="..tab
  local msg = http.get(url)
  msg = json.decode(msg)
  mirai.ReleaseSessionKey(session)
  if msg.code == 0 then
    return true
  else
    return false,msg.msg
  end
end

function mirai.memberAdmin(target,memberId,bool)
  local session = mirai.GetSessionKey()
  local target = dream.tostring(target)
  local memberId = dream.tostring(memberId)
  local bool = dream.tostring(bool)
  local url = http.url.."/memberAdmin"
  local tab = {
    sessionKey = session,
    target = target,
    memberId = memberId,
    assign = bool
  }
  tab = json.encode(tab)
  url = http.post..url.."&data="..tab
  local msg = http.get(url)
  mirai.ReleaseSessionKey(session)
  msg = json.decode(msg)
  if msg.code ~= 0 then
    return false,msg.msg
  else
    return true
  end
end

function mirai.forward(tab,msg,senderId,senderName)
  local senderId = dream.tostring(senderId)
  local senderName = dream.tostring(senderName)
  preview = {}
  for k,v in pairs(tab) do
    preview[#preview+1] = v
  end
  local data = {
    type = "Forward",
    display = {
      title = "群聊的聊天记录",
      brief = "[聊天记录]",
      source = "聊天记录",
      preview = preview,
      summary = "查看"..#tab.."条转发消息"
    }
  }
  data.nodeList = {}
  for k,v in pairs(tab) do
    data.nodeList[#data.nodeList+1] = {
      senderId = senderId,
      time = string.format("%u",os.time()),
      senderName = senderName or senderId,
      messageChain = {
        {
          type = "Plain",
          text = v
        }
      }
    }
  end
  data = {data}
  return mirai.sendMessage(data,msg)
end

return mirai