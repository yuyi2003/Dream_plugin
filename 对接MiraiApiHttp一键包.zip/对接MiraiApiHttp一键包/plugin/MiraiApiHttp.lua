if dream.MiraiApiHttp == true then
  dream.plugin.setConfig("MiraiApiHttp","http",8080)
  dream.plugin.setConfig("MiraiApiHttp","server",5700)
  dream.plugin.setConfig("MiraiApiHttp","verifyKey","1234567890") -- 这个改"1234567890"时候别删"，删了报错不归我管
else
  return {
  id = "MiraiApiHttp",
  version = 1.0,
  help = "对接mirai-api-http插件",
  author = "筑梦师V2.0",
  dep = "all",
  mode = false -- 不用MiraiApiHttp会禁用此插件
  }
end

function recall(msg)
  local messageId = dream.tostring(msg.fromMsg:match("ids=(.+),")):match("([0-9]+)")
  local Msg = msg.fromMsg:match("content=<not yet initialized>%](.+)$")
  if Msg == nil then
    return ""
  end
  Msg = Msg:gsub(dream.api.getDiceQQ(),""):gsub(" ","")
  if Msg == "#撤回" then
    local i,j = mirai.recall(messageId,msg)
    if i then
      return "撤回成功"
    else
      return "撤回失败："..j
    end
  end
end
dream.keyword.set("MiraiApiHttp","[mirai:quote:",recall,true)

function sleep(msg)
  if dream.api.permission(msg.fromGroup,dream.api.getDiceQQ()) == true then
    return "当前"..msg.fromDiceName.."没有管理权限呢～"
  end
  local str = {"*有什么吻上了"..msg.fromNick.."的眼睛#{SPLIT}安眠吧～","祝"..msg.fromNick.."一夜好梦～","繁星点点，伴"..msg.fromNick.."入睡～"}
  local hour = tonumber(os.date("%H"))
  if hour > 6 then
    if hour < 20 then
      mirai.mute(msg.fromGroup,msg.fromQQ,"36000")
      return "那么早就要睡了吗？那就奖励"..msg.fromNick.."一次睡眠时间吧～"
    end
  end
  local HOUR = {"一","二","三","四","五","六","七","八","九"}
  local MIN = {"零","一","二","三","四","五","六","七","八","九"}
  local MIN_ = {}
  for k,v in pairs(MIN) do
    MIN_[v] = k - 1
  end
  local hour = ZhaoDiceSDK.randomInt(6,9)
  local min = ZhaoDiceSDK.randomInt(1,7)
  local min_ = ZhaoDiceSDK.randomInt(1,10)
  if min == 7 then
    min_ = 1
  end
  local hour_str = HOUR[hour]
  local min_str
  if min == 2 then
    if min_ == 1 then
      min_str = "一十"
    else
      min_str = MIN[min]..MIN[min_]
    end
  else
    min_str = MIN[min]..MIN[min_]
  end
  local min = tonumber(MIN_[MIN[min]]..MIN_[MIN[min_]])
  local time
  if 19 < tonumber(os.date("%H")) then
    time = (24 - (tonumber(os.date("%H")) + 1))*3600 + (60-tonumber(os.date("%M")))*60
    time = time + hour*3600 + min*60
  elseif tonumber(os.date("%H")) > -1 then
    time = (60-tonumber(os.date("%M")))*60
    time = time + (hour-(tonumber(os.date("%H"))+1))*3600
    time = time + min*60
  end
  mirai.mute(msg.fromGroup,msg.fromQQ,time)
  return "#{AT-"..msg.fromQQ.."}\n定时之刻，针指为"..hour_str.."\n定分之刻，针指"..min_str.."\n指针流转，司夜之人伴汝入梦至"..hour.."时"..min.."分#{SPLIT}"..str[ZhaoDiceSDK.randomInt(1,#str)]
end
dream.keyword.set("MiraiApiHttp","蒂蒂伴我入",sleep)

function Title(msg)
  if dream.api.permission(msg.fromGroup,dream.api.getDiceQQ(),"OWNER") == false then
    return "当前"..msg.fromDiceName.."没有群主权限呢～"
  end
  local id,title = msg.fromMsg:match("^赐(.+)头衔(.+)$")
  if id == nil then
    return ""
  elseif title == nil then
    return ""
  elseif id == "我" then
    id = msg.fromQQ
  elseif not id:match("([0-9]+)") then
    return ""
  end
  id = id:match("([0-9]+)")
  local list = dream.api.getGroupsList(msg.fromGroup)
  local bool
  for i=1,#list.list do
    if list.list[i].uin == tonumber(id) then
      bool = true
      break
    else
      bool = false
    end
  end
  if not bool then
    return "群员"..id.."不存在×"
  end
  local b,r = mirai.SetTitle(msg.fromGroup,id,title)
  if b then
    return "设置成功"
  else
    return "设置失败："..r
  end
end
dream.keyword.set("MiraiApiHttp","赐",Title,true)

function toAdmin(msg)
  local qq = msg.fromMsg:match("^特赐(.+)管理员之位$")
  qq = qq:gsub(" ","")
  local bool,r = mirai.memberAdmin(msg.fromGroup,qq,true)
  if not bool then
    return "设置管理员失败："..r
  else
    return "设置成功"
  end
end
dream.keyword.set("MiraiApiHttp","特赐",toAdmin,true)

function removeAdmin(msg)
  local qq = msg.fromMsg:match("^剥夺(.+)管理员之位$")
  qq = qq:gsub(" ","")
  local bool,r = mirai.memberAdmin(msg.fromGroup,qq,false)
  if not bool then
    return "剥夺管理员失败："..r
  else
    return "剥夺成功"
  end
end
dream.keyword.set("MiraiApiHttp","剥夺",removeAdmin,true)

return {
  id = "MiraiApiHttp",
  version = 1.0,
  help = "对接mirai-api-http插件",
  author = "筑梦师V2.0",
  dep = "all",
  mode = true
}